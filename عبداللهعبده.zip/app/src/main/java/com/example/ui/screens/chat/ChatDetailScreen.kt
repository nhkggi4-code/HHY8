package com.example.ui.screens.chat

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Poll
import androidx.compose.material.icons.filled.Reply
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.local.entities.ChatEntity
import com.example.data.local.entities.MessageEntity
import com.example.ui.components.LegendAvatar
import com.example.ui.components.LegendShieldBanner
import com.example.ui.components.MessageStatusTicks
import com.example.ui.components.formatCallDuration
import com.example.ui.components.formatChatTimestamp
import com.example.ui.theme.CardSurfaceDark
import com.example.ui.theme.CardSurfaceElevated
import com.example.ui.theme.ChatBgDark
import com.example.ui.theme.DividerColor
import com.example.ui.theme.LegendGold
import com.example.ui.theme.LegendGoldBright
import com.example.ui.theme.LegendGoldDark
import com.example.ui.theme.LegendGoldLight
import com.example.ui.theme.LegendRed
import com.example.ui.theme.OnlineGreen
import com.example.ui.theme.ReceivedBubbleBg
import com.example.ui.theme.ReceivedBubbleBorder
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueAccent
import com.example.ui.theme.RoyalBlueMedium
import com.example.ui.theme.RoyalMidnight
import com.example.ui.theme.RoyalNavyDark
import com.example.ui.theme.SentBubbleBg
import com.example.ui.theme.SentBubbleGoldBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TopBarSurface
import com.example.ui.viewmodel.ChatViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatDetailScreen(
    viewModel: ChatViewModel,
    modifier: Modifier = Modifier
) {
    val currentChat by viewModel.currentChat.collectAsStateWithLifecycle()
    val messages by viewModel.currentMessages.collectAsStateWithLifecycle()

    var inputText by remember { mutableStateOf("") }
    var showAttachmentSheet by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    var isRecordingAudio by remember { mutableStateOf(false) }
    var recordingSeconds by remember { mutableIntStateOf(0) }
    var selectedMessageForMenu by remember { mutableStateOf<MessageEntity?>(null) }
    var replyToMessage by remember { mutableStateOf<MessageEntity?>(null) }

    val listState = rememberLazyListState()

    // Auto-scroll to latest message
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    // Audio recording timer simulation
    LaunchedEffect(isRecordingAudio) {
        if (isRecordingAudio) {
            recordingSeconds = 0
            while (isRecordingAudio) {
                kotlinx.coroutines.delay(1000)
                recordingSeconds++
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (currentChat != null) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            LegendAvatar(
                                name = currentChat!!.title,
                                avatarRes = currentChat!!.avatarRes,
                                size = 42.dp,
                                isOnline = currentChat!!.isOnline,
                                isVip = currentChat!!.isVipLegend
                            )

                            Spacer(modifier = Modifier.width(10.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = currentChat!!.title,
                                    color = if (currentChat!!.isVipLegend) LegendGoldBright else TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = when {
                                        currentChat!!.isTyping -> "يكتب الآن..."
                                        currentChat!!.isOnline -> "متصل الآن 🟢"
                                        currentChat!!.isGroup -> "${currentChat!!.groupMembersCount} عضواً أسطورياً"
                                        else -> "آخر ظهور اليوم"
                                    },
                                    color = if (currentChat!!.isTyping) LegendGoldBright else RoyalBlueAccent,
                                    fontSize = 12.sp,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.closeChat() },
                        modifier = Modifier.testTag("btn_back_from_chat")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "رجوع",
                            tint = LegendGoldBright
                        )
                    }
                },
                actions = {
                    if (currentChat != null) {
                        // Video Call Button
                        IconButton(
                            onClick = {
                                viewModel.startCall(
                                    contactId = currentChat!!.id,
                                    contactName = currentChat!!.title,
                                    contactAvatarRes = currentChat!!.avatarRes,
                                    isVideo = true
                                )
                            },
                            modifier = Modifier.testTag("btn_video_call")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Videocam,
                                contentDescription = "مكالمة فيديو",
                                tint = LegendGoldBright
                            )
                        }

                        // Voice Call Button
                        IconButton(
                            onClick = {
                                viewModel.startCall(
                                    contactId = currentChat!!.id,
                                    contactName = currentChat!!.title,
                                    contactAvatarRes = currentChat!!.avatarRes,
                                    isVideo = false
                                )
                            },
                            modifier = Modifier.testTag("btn_voice_call")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Call,
                                contentDescription = "مكالمة صوتية",
                                tint = LegendGoldBright
                            )
                        }

                        // Chat Menu
                        Box {
                            IconButton(
                                onClick = { showMenu = true },
                                modifier = Modifier.testTag("btn_chat_menu")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MoreVert,
                                    contentDescription = "خيارات المحادثة",
                                    tint = TextPrimary
                                )
                            }

                            DropdownMenu(
                                expanded = showMenu,
                                onDismissRequest = { showMenu = false },
                                modifier = Modifier
                                    .background(CardSurfaceDark)
                                    .border(1.dp, DividerColor, RoundedCornerShape(8.dp))
                            ) {
                                DropdownMenuItem(
                                    text = { Text("معلومات جهة الاتصال", color = TextPrimary) },
                                    onClick = { showMenu = false }
                                )
                                DropdownMenuItem(
                                    text = { Text("الوسائط والمستندات المشتركة", color = TextPrimary) },
                                    onClick = { showMenu = false }
                                )
                                DropdownMenuItem(
                                    text = { Text("🔒 قفل المحادثة برمز سري", color = LegendGoldBright) },
                                    onClick = { showMenu = false }
                                )
                                DropdownMenuItem(
                                    text = { Text("مسح محتوى المحادثة", color = LegendRed) },
                                    onClick = {
                                        showMenu = false
                                        currentChat?.id?.let { viewModel.clearChat(it) }
                                    }
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = TopBarSurface
                )
            )
        },
        bottomBar = {
            Column(
                modifier = Modifier
                    .background(TopBarSurface)
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                // Reply Quote Preview
                AnimatedVisibility(visible = replyToMessage != null) {
                    if (replyToMessage != null) {
                        Surface(
                            color = CardSurfaceElevated,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                .border(1.dp, LegendGold.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .width(3.dp)
                                        .height(32.dp)
                                        .background(LegendGoldBright)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = replyToMessage!!.senderName,
                                        color = LegendGoldBright,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                    Text(
                                        text = replyToMessage!!.text,
                                        color = TextSecondary,
                                        fontSize = 12.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                IconButton(
                                    onClick = { replyToMessage = null },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "إلغاء الرد",
                                        tint = TextMuted,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // AI Legend Smart Replies Bar
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val smartReplies = listOf(
                        "👑 أهلاً بك يا أسطورة!",
                        "👍 تم، جزاك الله خيراً",
                        "🌟 ما شاء الله تبارك الله",
                        "📞 سأتصل بك هاتفياً الآن",
                        "📄 أرسل لي الملف فضلاً"
                    )
                    items(smartReplies) { reply ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(CardSurfaceDark)
                                .border(1.dp, RoyalBlueAccent.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                                .clickable {
                                    viewModel.sendMessage(reply)
                                }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = reply,
                                color = LegendGoldLight,
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                // Input Bar Row
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (isRecordingAudio) {
                        // Live Audio Recording UI
                        val transition = rememberInfiniteTransition(label = "mic_pulse")
                        val scale by transition.animateFloat(
                            initialValue = 1f,
                            targetValue = 1.25f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(600),
                                repeatMode = RepeatMode.Reverse
                            ),
                            label = "pulse"
                        )

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(24.dp))
                                .background(CardSurfaceDark)
                                .border(1.dp, LegendRed.copy(alpha = 0.5f), RoundedCornerShape(24.dp))
                                .padding(horizontal = 16.dp, vertical = 10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .scale(scale)
                                    .clip(CircleShape)
                                    .background(LegendRed)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "جاري التسجيل الملكي: ${formatCallDuration(recordingSeconds)}",
                                color = TextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = "إلغاء",
                                color = LegendRed,
                                fontSize = 13.sp,
                                modifier = Modifier
                                    .clickable { isRecordingAudio = false }
                                    .padding(horizontal = 8.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        FloatingActionButton(
                            onClick = {
                                isRecordingAudio = false
                                viewModel.sendMessage(
                                    text = "تسجيل صوتي",
                                    messageType = "VOICE_NOTE",
                                    mediaDuration = recordingSeconds
                                )
                            },
                            containerColor = LegendGold,
                            contentColor = RoyalNavyDark,
                            shape = CircleShape,
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("btn_send_voice_note")
                        ) {
                            Icon(imageVector = Icons.AutoMirrored.Filled.Send, contentDescription = "إرسال التسجيل")
                        }
                    } else {
                        // Standard Input Row
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(26.dp))
                                .background(CardSurfaceDark)
                                .border(1.dp, DividerColor, RoundedCornerShape(26.dp))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            IconButton(
                                onClick = {
                                    // Quick Emoji injection
                                    inputText += "👑"
                                },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.EmojiEmotions,
                                    contentDescription = "رموز تعبيرية",
                                    tint = LegendGoldBright,
                                    modifier = Modifier.size(22.dp)
                                )
                            }

                            OutlinedTextField(
                                value = inputText,
                                onValueChange = { inputText = it },
                                placeholder = {
                                    Text("اكتب رسالة ملكية...", color = TextMuted, fontSize = 14.sp)
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("chat_input_field"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent,
                                    focusedBorderColor = Color.Transparent,
                                    unfocusedBorderColor = Color.Transparent,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary
                                ),
                                maxLines = 4
                            )

                            // Attachment Button
                            IconButton(
                                onClick = { showAttachmentSheet = true },
                                modifier = Modifier
                                    .size(36.dp)
                                    .testTag("btn_attach_file")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AttachFile,
                                    contentDescription = "إرفاق",
                                    tint = TextSecondary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }

                            // Camera Quick Button
                            IconButton(
                                onClick = {
                                    viewModel.sendMessage(
                                        text = "صورة ملتقطة بالكاميرا عالية الدقة 📸",
                                        messageType = "IMAGE"
                                    )
                                },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CameraAlt,
                                    contentDescription = "كاميرا",
                                    tint = TextSecondary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        // Mic or Send FAB
                        if (inputText.isNotBlank()) {
                            FloatingActionButton(
                                onClick = {
                                    val text = inputText
                                    inputText = ""
                                    val replyId = replyToMessage?.id
                                    val replyTxt = replyToMessage?.text
                                    replyToMessage = null
                                    viewModel.sendMessage(
                                        text = text,
                                        messageType = "TEXT",
                                        replyToId = replyId,
                                        replyToText = replyTxt
                                    )
                                },
                                containerColor = LegendGold,
                                contentColor = RoyalNavyDark,
                                shape = CircleShape,
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("btn_send_message")
                            ) {
                                Icon(imageVector = Icons.AutoMirrored.Filled.Send, contentDescription = "إرسال")
                            }
                        } else {
                            FloatingActionButton(
                                onClick = {
                                    isRecordingAudio = true
                                },
                                containerColor = LegendGold,
                                contentColor = RoyalNavyDark,
                                shape = CircleShape,
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("btn_record_voice")
                            ) {
                                Icon(imageVector = Icons.Default.Mic, contentDescription = "تسجيل صوتي")
                            }
                        }
                    }
                }
            }
        },
        containerColor = ChatBgDark,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(ChatBgDark)
        ) {
            // Wallpaper Background
            Image(
                painter = painterResource(id = R.drawable.img_chat_wallpaper),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                alpha = 0.15f,
                modifier = Modifier.fillMaxSize()
            )

            // Message list
            LazyColumn(
                state = listState,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                item {
                    Box(modifier = Modifier.padding(bottom = 12.dp)) {
                        LegendShieldBanner()
                    }
                }

                items(messages, key = { it.id }) { message ->
                    MessageBubble(
                        message = message,
                        onReactionSelect = { reaction ->
                            viewModel.setReaction(message.id, reaction)
                        },
                        onReplyClick = {
                            replyToMessage = message
                        },
                        onStarClick = {
                            viewModel.toggleStarMessage(message.id)
                        },
                        onDeleteClick = {
                            viewModel.deleteMessage(message.id)
                        }
                    )
                }
            }
        }

        // Media Attachment Bottom Sheet
        if (showAttachmentSheet) {
            AttachmentBottomSheet(
                onDismiss = { showAttachmentSheet = false },
                onOptionSelected = { type, snippet ->
                    showAttachmentSheet = false
                    viewModel.sendMessage(
                        text = snippet,
                        messageType = type,
                        fileName = if (type == "DOCUMENT") "مستند_الاسطورة_محمد.pdf" else null,
                        mediaDuration = if (type == "AUDIO") 65 else 0
                    )
                }
            )
        }
    }
}

@Composable
fun MessageBubble(
    message: MessageEntity,
    onReactionSelect: (String?) -> Unit,
    onReplyClick: () -> Unit,
    onStarClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    var showMessageMenu by remember { mutableStateOf(false) }
    var isAudioPlaying by remember { mutableStateOf(false) }

    val isFromMe = message.isFromMe

    Column(
        horizontalAlignment = if (isFromMe) Alignment.End else Alignment.Start,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .testTag("message_bubble_${message.id}")
    ) {
        Box(contentAlignment = Alignment.BottomEnd) {
            Surface(
                color = if (isFromMe) SentBubbleBg else ReceivedBubbleBg,
                shape = RoundedCornerShape(
                    topStart = 16.dp,
                    topEnd = 16.dp,
                    bottomStart = if (isFromMe) 16.dp else 2.dp,
                    bottomEnd = if (isFromMe) 2.dp else 16.dp
                ),
                modifier = Modifier
                    .widthIn(min = 100.dp, max = 300.dp)
                    .border(
                        1.dp,
                        if (isFromMe) SentBubbleGoldBorder else ReceivedBubbleBorder,
                        RoundedCornerShape(
                            topStart = 16.dp,
                            topEnd = 16.dp,
                            bottomStart = if (isFromMe) 16.dp else 2.dp,
                            bottomEnd = if (isFromMe) 2.dp else 16.dp
                        )
                    )
                    .clickable { showMessageMenu = true }
            ) {
                Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                    // Sender name for group chats
                    if (!isFromMe && message.senderName != "أنا") {
                        Text(
                            text = message.senderName,
                            color = LegendGoldBright,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(bottom = 2.dp)
                        )
                    }

                    // Quoted Reply if present
                    if (!message.replyToText.isNullOrEmpty()) {
                        Surface(
                            color = RoyalMidnight.copy(alpha = 0.7f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 6.dp)
                                .border(1.dp, LegendGold.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                        ) {
                            Row(modifier = Modifier.padding(6.dp)) {
                                Box(
                                    modifier = Modifier
                                        .width(2.dp)
                                        .height(24.dp)
                                        .background(LegendGold)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = message.replyToText,
                                    color = TextSecondary,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    // Content by type
                    when (message.messageType) {
                        "VOICE_NOTE", "AUDIO" -> {
                            VoiceNoteBubbleContent(
                                durationSeconds = if (message.mediaDuration > 0) message.mediaDuration else 24,
                                isPlaying = isAudioPlaying,
                                onPlayToggle = { isAudioPlaying = !isAudioPlaying }
                            )
                        }
                        "IMAGE" -> {
                            Column {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(160.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(RoyalBlueMedium)
                                ) {
                                    Image(
                                        painter = painterResource(id = R.drawable.img_app_icon),
                                        contentDescription = "صورة",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                                if (message.text.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = message.text,
                                        color = TextPrimary,
                                        fontSize = 14.sp
                                    )
                                }
                            }
                        }
                        "DOCUMENT" -> {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                            ) {
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(LegendGold)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Description,
                                        contentDescription = "مستند",
                                        tint = RoyalNavyDark
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = message.fileName ?: "مستند_الاسطورة.pdf",
                                        color = TextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = "2.4 ميغابايت • PDF",
                                        color = TextSecondary,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                        "LOCATION" -> {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.LocationOn,
                                    contentDescription = "موقع",
                                    tint = LegendRed,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "موقع مباشر (الرياض، المملكة العربية السعودية)",
                                    color = TextPrimary,
                                    fontSize = 13.sp
                                )
                            }
                        }
                        "POLL" -> {
                            Column(modifier = Modifier.padding(vertical = 4.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Poll,
                                        contentDescription = "استطلاع",
                                        tint = LegendGoldBright,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "استطلاع رأي: ما رأيك في واتساب الاسطورة؟",
                                        color = LegendGoldBright,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(CardSurfaceDark)
                                        .padding(8.dp)
                                ) {
                                    Text("👑 ممتاز وفخم جداً (88%)", color = TextPrimary, fontSize = 12.sp)
                                }
                            }
                        }
                        else -> {
                            Text(
                                text = message.text,
                                color = TextPrimary,
                                fontSize = 15.sp,
                                lineHeight = 20.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Timestamp & Status Ticks
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.End,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (message.isStarred) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = "مميزة بنجمة",
                                tint = LegendGoldBright,
                                modifier = Modifier
                                    .size(12.dp)
                                    .padding(end = 4.dp)
                            )
                        }

                        Text(
                            text = formatChatTimestamp(message.timestamp),
                            color = TextMuted,
                            fontSize = 10.sp
                        )

                        if (isFromMe) {
                            Spacer(modifier = Modifier.width(4.dp))
                            MessageStatusTicks(status = message.status)
                        }
                    }
                }
            }

            // Reaction Badge if present
            if (!message.reaction.isNullOrEmpty()) {
                Box(
                    modifier = Modifier
                        .padding(bottom = 0.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(CardSurfaceDark)
                        .border(1.dp, LegendGold.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(text = message.reaction, fontSize = 12.sp)
                }
            }
        }

        // Message Options Context Menu
        DropdownMenu(
            expanded = showMessageMenu,
            onDismissRequest = { showMessageMenu = false },
            modifier = Modifier
                .background(CardSurfaceDark)
                .border(1.dp, DividerColor, RoundedCornerShape(8.dp))
        ) {
            // Reaction picker
            DropdownMenuItem(
                text = {
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        val emojis = listOf("👑", "❤️", "👍", "😂", "😮", "🙏")
                        emojis.forEach { emoji ->
                            Text(
                                text = emoji,
                                fontSize = 18.sp,
                                modifier = Modifier
                                    .clickable {
                                        onReactionSelect(emoji)
                                        showMessageMenu = false
                                    }
                                    .padding(4.dp)
                            )
                        }
                    }
                },
                onClick = {}
            )

            DropdownMenuItem(
                text = { Text("رد على الرسالة", color = TextPrimary) },
                onClick = {
                    showMessageMenu = false
                    onReplyClick()
                }
            )

            DropdownMenuItem(
                text = { Text(if (message.isStarred) "إلغاء التمييز بنجمة" else "تمييز بنجمة", color = TextPrimary) },
                onClick = {
                    showMessageMenu = false
                    onStarClick()
                }
            )

            DropdownMenuItem(
                text = { Text("حذف الرسالة", color = LegendRed) },
                onClick = {
                    showMessageMenu = false
                    onDeleteClick()
                }
            )
        }
    }
}

@Composable
fun VoiceNoteBubbleContent(
    durationSeconds: Int,
    isPlaying: Boolean,
    onPlayToggle: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(LegendGold)
                .clickable(onClick = onPlayToggle)
        ) {
            Icon(
                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = if (isPlaying) "إيقاف مؤقت" else "تشغيل",
                tint = RoyalNavyDark,
                modifier = Modifier.size(24.dp)
            )
        }

        Spacer(modifier = Modifier.width(10.dp))

        Column(modifier = Modifier.weight(1f)) {
            // Waveform Graphic Simulation
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                val heights = listOf(8, 14, 22, 12, 18, 26, 16, 20, 10, 24, 18, 14, 22, 16, 8)
                heights.forEachIndexed { index, h ->
                    val isPassed = isPlaying && index < 8
                    Box(
                        modifier = Modifier
                            .width(3.dp)
                            .height(h.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(if (isPassed) LegendGoldBright else RoyalBlueAccent.copy(alpha = 0.7f))
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "0:${String.format("%02d", durationSeconds)} • تسجيل صوتي فائق النقاء",
                color = TextSecondary,
                fontSize = 11.sp
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AttachmentBottomSheet(
    onDismiss: () -> Unit,
    onOptionSelected: (type: String, snippet: String) -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(),
        containerColor = CardSurfaceDark
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "إرفاق وسائط ملكية",
                color = LegendGoldBright,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            Row(
                horizontalArrangement = Arrangement.SpaceAround,
                modifier = Modifier.fillMaxWidth()
            ) {
                AttachmentOptionItem(
                    icon = Icons.Default.Description,
                    label = "مستند",
                    color = Color(0xFF5E60CE),
                    onClick = { onOptionSelected("DOCUMENT", "📄 تم إرفاق ملف مستند جديد") }
                )
                AttachmentOptionItem(
                    icon = Icons.Default.CameraAlt,
                    label = "كاميرا",
                    color = Color(0xFFE63946),
                    onClick = { onOptionSelected("IMAGE", "📷 صورة فورية بجودة عالية") }
                )
                AttachmentOptionItem(
                    icon = Icons.Default.Image,
                    label = "معرض الصور",
                    color = Color(0xFF9B5DE5),
                    onClick = { onOptionSelected("IMAGE", "🖼️ تم إرسال صورة من المعرض") }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                horizontalArrangement = Arrangement.SpaceAround,
                modifier = Modifier.fillMaxWidth()
            ) {
                AttachmentOptionItem(
                    icon = Icons.Default.GraphicEq,
                    label = "صوت",
                    color = Color(0xFFF77F00),
                    onClick = { onOptionSelected("AUDIO", "🎵 مقطع صوتي نقي") }
                )
                AttachmentOptionItem(
                    icon = Icons.Default.LocationOn,
                    label = "موقع مباشر",
                    color = Color(0xFF06D6A0),
                    onClick = { onOptionSelected("LOCATION", "📍 مشاركة الموقع المباشر") }
                )
                AttachmentOptionItem(
                    icon = Icons.Default.Poll,
                    label = "استطلاع رأي",
                    color = LegendGold,
                    onClick = { onOptionSelected("POLL", "📊 استطلاع رأي جديد") }
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
fun AttachmentOptionItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    color: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(8.dp)
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(54.dp)
                .clip(CircleShape)
                .background(color)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = Color.White,
                modifier = Modifier.size(26.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            color = TextPrimary,
            fontSize = 12.sp
        )
    }
}
