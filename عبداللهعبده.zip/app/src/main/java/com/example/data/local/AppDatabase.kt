package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.local.dao.CallDao
import com.example.data.local.dao.ChatDao
import com.example.data.local.dao.LegendConfigDao
import com.example.data.local.dao.MessageDao
import com.example.data.local.dao.StatusDao
import com.example.data.local.entities.CallEntity
import com.example.data.local.entities.ChatEntity
import com.example.data.local.entities.LegendConfigEntity
import com.example.data.local.entities.MessageEntity
import com.example.data.local.entities.StatusEntity

@Database(
    entities = [
        ChatEntity::class,
        MessageEntity::class,
        CallEntity::class,
        StatusEntity::class,
        LegendConfigEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun chatDao(): ChatDao
    abstract fun messageDao(): MessageDao
    abstract fun callDao(): CallDao
    abstract fun statusDao(): StatusDao
    abstract fun legendConfigDao(): LegendConfigDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "whatsapp_legend_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
