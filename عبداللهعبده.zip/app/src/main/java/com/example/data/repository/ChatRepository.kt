package com.example.data.repository

import com.example.R
import com.example.data.local.AppDatabase
import com.example.data.local.entities.CallEntity
import com.example.data.local.entities.ChatEntity
import com.example.data.local.entities.LegendConfigEntity
import com.example.data.local.entities.MessageEntity
import com.example.data.local.entities.StatusEntity
import com.example.data.models.CallDirection
import com.example.data.models.CallType
import com.example.data.models.MessageStatus
import com.example.data.models.MessageType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import java.util.UUID

class ChatRepository(private val db: AppDatabase) {

    private val chatDao = db.chatDao()
    private val messageDao = db.messageDao()
    private val callDao = db.callDao()
    private val statusDao = db.statusDao()
    private val configDao = db.legendConfigDao()

    val activeChats: Flow<List<ChatEntity>> = chatDao.getActiveChats()
    val groupChats: Flow<List<ChatEntity>> = chatDao.getGroupChats()
    val archivedChats: Flow<List<ChatEntity>> = chatDao.getArchivedChats()
    val allCalls: Flow<List<CallEntity>> = callDao.getAllCalls()
    val allStatuses: Flow<List<StatusEntity>> = statusDao.getAllStatuses()
    val legendConfig: Flow<LegendConfigEntity?> = configDao.getConfigFlow()

    fun getMessagesForChat(chatId: String): Flow<List<MessageEntity>> =
        messageDao.getMessagesForChat(chatId)

    fun getChatByIdFlow(chatId: String): Flow<ChatEntity?> =
        chatDao.getChatByIdFlow(chatId)

    suspend fun getChatById(chatId: String): ChatEntity? =
        chatDao.getChatById(chatId)

    suspend fun ensureInitialDataSeeded() {
        val currentConfig = configDao.getConfig()
        if (currentConfig == null) {
            configDao.saveConfig(
                LegendConfigEntity(
                    id = 1,
                    userName = "الاسطورة محمد",
                    userPhone = "+966 50 777 8899",
                    userBio = "👑 مرحباً بي في واتساب الاسطورة محمد | الإصدار الملكي",
                    userAvatarRes = R.drawable.img_legend_avatar,
                    isLoggedIn = true,
                    antiDeleteMessages = true,
                    autoReplyEnabled = false
                )
            )
        }

        val existing = chatDao.getActiveChats().firstOrNull()
        if (existing.isNullOrEmpty()) {
            seedInitialContent()
        }
    }

    private suspend fun seedInitialContent() {
        val now = System.currentTimeMillis()

        val chats = listOf(
            ChatEntity(
                id = "chat_legend",
                title = "الاسطورة محمد 👑",
                phone = "+966 55 000 0001",
                avatarRes = R.drawable.img_legend_avatar,
                isGroup = false,
                isPinned = true,
                unreadCount = 2,
                lastMessage = "أهلاً بك في نسختك الخاصة من واتساب الاسطورة! استمتع بكافة الميزات الملكية 🌟",
                lastTimestamp = now - 1000 * 60 * 5,
                lastMessageStatus = "DELIVERED",
                isOnline = true,
                customBio = "المطور وصاحب الإصدار الملكي الحصري 👑",
                isVipLegend = true
            ),
            ChatEntity(
                id = "chat_group_legends",
                title = "أساطير العرب 👑 (مجموعة رسمية)",
                phone = "",
                avatarRes = R.drawable.img_app_icon,
                isGroup = true,
                groupMembersCount = 340,
                isPinned = true,
                unreadCount = 5,
                lastMessage = "م. فيصل: تم تفعيل مكالمات الفيديو فائقة الدقة للجميع 🚀",
                lastTimestamp = now - 1000 * 60 * 18,
                lastMessageStatus = "READ",
                isOnline = true,
                customBio = "المجتمع الرسمي لمستخدمي واتساب الاسطورة محمد"
            ),
            ChatEntity(
                id = "chat_ahmed",
                title = "المهندس أحمد التقني",
                phone = "+966 50 111 2233",
                avatarRes = null,
                isGroup = false,
                isPinned = false,
                unreadCount = 0,
                lastMessage = "📄 أرسلت لك ملف التوثيق ومستندات النسخة الملكية",
                lastTimestamp = now - 1000 * 60 * 60 * 2,
                lastMessageStatus = "READ",
                isOnline = true,
                customBio = "مهندس نظم ومطور برمجيات 💻"
            ),
            ChatEntity(
                id = "chat_sarah",
                title = "د. سارة المنصور",
                phone = "+966 54 888 9900",
                avatarRes = null,
                isGroup = false,
                isPinned = false,
                unreadCount = 1,
                lastMessage = "🎤 تسجيل صوتي (0:42)",
                lastTimestamp = now - 1000 * 60 * 60 * 5,
                lastMessageStatus = "DELIVERED",
                isOnline = false,
                customBio = "استشارية تقنية المعلومات والأمن السيبراني"
            ),
            ChatEntity(
                id = "chat_family",
                title = "جروب العائلة الكريمة ❤️",
                phone = "",
                avatarRes = null,
                isGroup = true,
                groupMembersCount = 18,
                isPinned = false,
                unreadCount = 0,
                lastMessage = "أبو محمد: جمعة مباركة على الجميع وحفظكم الله جميعاً",
                lastTimestamp = now - 1000 * 60 * 60 * 12,
                lastMessageStatus = "READ",
                isOnline = false,
                customBio = "ملتقى الأهل والأحباب ❤️"
            ),
            ChatEntity(
                id = "chat_khalid",
                title = "الأستاذ خالد العتيبي",
                phone = "+966 56 333 4455",
                avatarRes = null,
                isGroup = false,
                isPinned = false,
                unreadCount = 0,
                lastMessage = "شكراً جزيلاً لك على سرعة الاستجابة والدعم المستمر 👍",
                lastTimestamp = now - 1000 * 60 * 60 * 24,
                lastMessageStatus = "READ",
                isOnline = false,
                customBio = "لا إله إلا أنت سبحانك إني كنت من الظالمين"
            ),
            ChatEntity(
                id = "chat_support_vip",
                title = "دعم الاسطورة VIP ⚡",
                phone = "+966 800 124 5555",
                avatarRes = R.drawable.img_app_icon,
                isGroup = false,
                isPinned = false,
                unreadCount = 0,
                lastMessage = "فريق الدعم الفني جاهز لخدمتكم على مدار الساعة",
                lastTimestamp = now - 1000 * 60 * 60 * 48,
                lastMessageStatus = "READ",
                isOnline = true,
                customBio = "قناة الدعم الفني والمساعد الذكي لواتساب الاسطورة"
            )
        )

        chatDao.insertChats(chats)

        // Seed messages for chat_legend
        val legendMessages = listOf(
            MessageEntity(
                id = "msg_leg_1",
                chatId = "chat_legend",
                senderId = "legend",
                senderName = "الاسطورة محمد",
                text = "السلام عليكم ورحمة الله وبركاته يا غالي! مرحباً بك في الإصدار الجديد من تطبيق واتساب الاسطورة محمد 👑",
                timestamp = now - 1000 * 60 * 30,
                isFromMe = false,
                status = "READ",
                messageType = "TEXT"
            ),
            MessageEntity(
                id = "msg_leg_2",
                chatId = "chat_legend",
                senderId = "me",
                senderName = "أنا",
                text = "وعليكم السلام يا أسطورة! النسخة جداً مميزة بالأزرق الملكي والذهبي، المظهر رائع ومتقن ما شاء الله 💙👑",
                timestamp = now - 1000 * 60 * 25,
                isFromMe = true,
                status = "READ",
                messageType = "TEXT",
                reaction = "👑"
            ),
            MessageEntity(
                id = "msg_leg_3",
                chatId = "chat_legend",
                senderId = "legend",
                senderName = "الاسطورة محمد",
                text = "تسلم يا غالي! قمنا بتضمين ميزات الخصوصية الفائقة: إخفاء الظهور، عدم حذف الرسائل، ثيمات ذهبية، ومكالمات صوت وفيديو فائقة الوضوح 🛡️✨",
                timestamp = now - 1000 * 60 * 15,
                isFromMe = false,
                status = "READ",
                messageType = "TEXT"
            ),
            MessageEntity(
                id = "msg_leg_4",
                chatId = "chat_legend",
                senderId = "legend",
                senderName = "الاسطورة محمد",
                text = "تسجيل صوتي خاص يوضح طريقة استخدام أدوات الاسطورة المتقدمة 🎙️",
                timestamp = now - 1000 * 60 * 10,
                isFromMe = false,
                status = "READ",
                messageType = "VOICE_NOTE",
                mediaDuration = 28
            ),
            MessageEntity(
                id = "msg_leg_5",
                chatId = "chat_legend",
                senderId = "legend",
                senderName = "الاسطورة محمد",
                text = "أهلاً بك في نسختك الخاصة من واتساب الاسطورة! استمتع بكافة الميزات الملكية 🌟",
                timestamp = now - 1000 * 60 * 5,
                isFromMe = false,
                status = "DELIVERED",
                messageType = "TEXT"
            )
        )
        messageDao.insertMessages(legendMessages)

        // Seed messages for group chat
        val groupMessages = listOf(
            MessageEntity(
                id = "msg_grp_1",
                chatId = "chat_group_legends",
                senderId = "user_ahmed",
                senderName = "م. أحمد",
                text = "يا شباب هل جربتم ميزة المكالمات المشفرة الجديدة في واتساب الاسطورة؟ الجودة مذهلة!",
                timestamp = now - 1000 * 60 * 45,
                isFromMe = false,
                status = "READ",
                messageType = "TEXT"
            ),
            MessageEntity(
                id = "msg_grp_2",
                chatId = "chat_group_legends",
                senderId = "user_sarah",
                senderName = "د. سارة",
                text = "نعم الصوت نقي جداً وبدون أي تقطيع 👍",
                timestamp = now - 1000 * 60 * 30,
                isFromMe = false,
                status = "READ",
                messageType = "TEXT",
                reaction = "👍"
            ),
            MessageEntity(
                id = "msg_grp_3",
                chatId = "chat_group_legends",
                senderId = "user_faisal",
                senderName = "م. فيصل",
                text = "تم تفعيل مكالمات الفيديو فائقة الدقة للجميع 🚀",
                timestamp = now - 1000 * 60 * 18,
                isFromMe = false,
                status = "READ",
                messageType = "TEXT"
            )
        )
        messageDao.insertMessages(groupMessages)

        // Seed calls
        val calls = listOf(
            CallEntity(
                id = "call_1",
                contactId = "chat_legend",
                contactName = "الاسطورة محمد 👑",
                contactAvatarRes = R.drawable.img_legend_avatar,
                callType = "VIDEO",
                direction = "INCOMING",
                timestamp = now - 1000 * 60 * 120,
                durationSeconds = 860
            ),
            CallEntity(
                id = "call_2",
                contactId = "chat_ahmed",
                contactName = "المهندس أحمد التقني",
                contactAvatarRes = null,
                callType = "VOICE",
                direction = "OUTGOING",
                timestamp = now - 1000 * 60 * 60 * 6,
                durationSeconds = 225
            ),
            CallEntity(
                id = "call_3",
                contactId = "chat_sarah",
                contactName = "د. سارة المنصور",
                contactAvatarRes = null,
                callType = "VOICE",
                direction = "MISSED",
                timestamp = now - 1000 * 60 * 60 * 20,
                durationSeconds = 0
            ),
            CallEntity(
                id = "call_4",
                contactId = "chat_legend",
                contactName = "الاسطورة محمد 👑",
                contactAvatarRes = R.drawable.img_legend_avatar,
                callType = "VOICE",
                direction = "OUTGOING",
                timestamp = now - 1000 * 60 * 60 * 48,
                durationSeconds = 540
            )
        )
        callDao.insertCalls(calls)

        // Seed Statuses
        val statuses = listOf(
            StatusEntity(
                id = "stat_mine",
                authorName = "حالتي",
                authorAvatarRes = R.drawable.img_legend_avatar,
                timestamp = now - 1000 * 60 * 40,
                text = "✨ أهلاً بكم في عالم واتساب الاسطورة محمد | المراسلة بإتقان ملكي 💙👑",
                bgColorHex = "#0B192C",
                mediaRes = null,
                isViewed = true,
                isMine = true
            ),
            StatusEntity(
                id = "stat_legend",
                authorName = "الاسطورة محمد 👑",
                authorAvatarRes = R.drawable.img_legend_avatar,
                timestamp = now - 1000 * 60 * 60 * 2,
                text = "👑 تم إطلاق النسخة الرسمية المطورة من واتساب الاسطورة محمد بأعلى معايير الأمان والسرعة",
                bgColorHex = "#1E3E62",
                mediaRes = R.drawable.img_app_icon,
                isViewed = false,
                isMine = false
            ),
            StatusEntity(
                id = "stat_ahmed",
                authorName = "المهندس أحمد التقني",
                authorAvatarRes = null,
                timestamp = now - 1000 * 60 * 60 * 4,
                text = "💻 تطوير مستمر وتحديثات خرافية قادمة في عالم التقنية",
                bgColorHex = "#0F264A",
                mediaRes = null,
                isViewed = false,
                isMine = false
            ),
            StatusEntity(
                id = "stat_sarah",
                authorName = "د. سارة المنصور",
                authorAvatarRes = null,
                timestamp = now - 1000 * 60 * 60 * 8,
                text = "☕ يوم مثمر وهادئ مليء بالإنجازات بإذن الله",
                bgColorHex = "#2A2408",
                mediaRes = null,
                isViewed = true,
                isMine = false
            )
        )
        statusDao.insertStatuses(statuses)
    }

    suspend fun sendMessage(
        chatId: String,
        text: String,
        messageType: String = "TEXT",
        mediaDuration: Int = 0,
        fileName: String? = null,
        replyToId: String? = null,
        replyToText: String? = null
    ) {
        val now = System.currentTimeMillis()
        val msgId = "msg_" + UUID.randomUUID().toString()
        val newMessage = MessageEntity(
            id = msgId,
            chatId = chatId,
            senderId = "me",
            senderName = "أنا",
            text = text,
            timestamp = now,
            isFromMe = true,
            status = "SENT",
            messageType = messageType,
            mediaDuration = mediaDuration,
            fileName = fileName,
            replyToMessageId = replyToId,
            replyToText = replyToText
        )

        messageDao.insertMessage(newMessage)
        val snippet = when (messageType) {
            "VOICE_NOTE" -> "🎤 تسجيل صوتي"
            "IMAGE" -> "📷 صورة"
            "DOCUMENT" -> "📄 $fileName"
            "LOCATION" -> "📍 موقع جغرافي"
            "POLL" -> "📊 استطلاع رأي"
            else -> text
        }
        chatDao.updateLastMessage(chatId, snippet, now, "SENT", isTyping = false)

        // After a brief moment, mark as DELIVERED then READ
        CoroutineScope(Dispatchers.IO).launch {
            delay(800)
            messageDao.updateMessageStatus(msgId, "DELIVERED")
            chatDao.updateLastMessage(chatId, snippet, now, "DELIVERED")
            delay(1200)
            messageDao.updateMessageStatus(msgId, "READ")
            chatDao.updateLastMessage(chatId, snippet, now, "READ")

            // Realistic auto-reply simulation from contact
            simulateContactReply(chatId, text)
        }
    }

    private suspend fun simulateContactReply(chatId: String, userMessage: String) {
        val chat = chatDao.getChatById(chatId) ?: return
        delay(1500)
        chatDao.updateLastMessage(chatId, "يكتب الآن...", System.currentTimeMillis(), "READ", isTyping = true)
        delay(2500)

        val replyText = generateContextualReply(chat, userMessage)
        val replyTime = System.currentTimeMillis()
        val replyId = "reply_" + UUID.randomUUID().toString()

        val replyMsg = MessageEntity(
            id = replyId,
            chatId = chatId,
            senderId = chat.id,
            senderName = chat.title,
            text = replyText,
            timestamp = replyTime,
            isFromMe = false,
            status = "READ",
            messageType = "TEXT"
        )

        messageDao.insertMessage(replyMsg)
        chatDao.updateLastMessage(chatId, replyText, replyTime, "READ", isTyping = false)
    }

    private fun generateContextualReply(chat: ChatEntity, userMessage: String): String {
        return when {
            chat.isVipLegend -> {
                if (userMessage.contains("سلام") || userMessage.contains("مرحبا")) {
                    "وعليكم السلام ورحمة الله وبركاته! حياك الله في واتساب الاسطورة محمد، دائماً في خدمتك يا ملك 👑"
                } else if (userMessage.contains("ميزة") || userMessage.contains("تحديث") || userMessage.contains("جديد")) {
                    "الإصدار الحالي يحتوي على أفضل محرك تشفير ومكالمات فائقة الوضوح، مع تخصيص كامل للواجهة الملكية ⚡"
                } else {
                    "أشكرك على رسالتك يا غالي! كل التقدير لك ولتواجدك معنا في مجتمع واتساب الاسطورة محمد 👑✨"
                }
            }
            chat.isGroup -> {
                "أهلاً بك يا بطل في مجموعة الأساطير! نشكرك على تفاعلك الدائم 👍"
            }
            userMessage.contains("صوت") || userMessage.contains("مكالمة") -> {
                "أنا متاح لمكالمة صوتية أو فيديو واضحة عبر واتساب الاسطورة في أي وقت يناسبك 📞"
            }
            userMessage.contains("شكرا") || userMessage.contains("تسلم") -> {
                "العفو يا غالي، في خدمتك دائماً بإذن الله ❤️"
            }
            else -> {
                "وصلت رسالتك بوضوح عبر واتساب الاسطورة محمد، تسلم وجزاك الله خيراً! 🌟"
            }
        }
    }

    suspend fun clearUnread(chatId: String) = chatDao.clearUnread(chatId)
    suspend fun togglePin(chatId: String) = chatDao.togglePin(chatId)
    suspend fun toggleArchive(chatId: String) = chatDao.toggleArchive(chatId)
    suspend fun toggleMute(chatId: String) = chatDao.toggleMute(chatId)
    suspend fun deleteChat(chatId: String) {
        messageDao.clearChatMessages(chatId)
        chatDao.deleteChat(chatId)
    }

    suspend fun setReaction(messageId: String, reaction: String?) =
        messageDao.setMessageReaction(messageId, reaction)

    suspend fun toggleStarMessage(messageId: String) =
        messageDao.toggleStarMessage(messageId)

    suspend fun deleteMessage(messageId: String) =
        messageDao.deleteMessage(messageId)

    suspend fun clearChatMessages(chatId: String) =
        messageDao.clearChatMessages(chatId)

    suspend fun addCall(
        contactId: String,
        contactName: String,
        contactAvatarRes: Int?,
        callType: String,
        direction: String,
        durationSeconds: Int = 0
    ) {
        val call = CallEntity(
            id = "call_" + UUID.randomUUID().toString(),
            contactId = contactId,
            contactName = contactName,
            contactAvatarRes = contactAvatarRes,
            callType = callType,
            direction = direction,
            timestamp = System.currentTimeMillis(),
            durationSeconds = durationSeconds
        )
        callDao.insertCall(call)
    }

    suspend fun clearAllCalls() = callDao.clearAllCalls()

    suspend fun addStatus(text: String, bgColorHex: String = "#0A192F") {
        val status = StatusEntity(
            id = "stat_" + UUID.randomUUID().toString(),
            authorName = "حالتي",
            authorAvatarRes = R.drawable.img_legend_avatar,
            timestamp = System.currentTimeMillis(),
            text = text,
            bgColorHex = bgColorHex,
            isViewed = true,
            isMine = true
        )
        statusDao.insertStatus(status)
    }

    suspend fun markStatusViewed(statusId: String) = statusDao.markStatusViewed(statusId)

    suspend fun createNewChat(
        name: String,
        phone: String,
        isGroup: Boolean = false,
        membersCount: Int = 0
    ): String {
        val chatId = if (isGroup) "grp_" + UUID.randomUUID().toString().take(8) else "usr_" + UUID.randomUUID().toString().take(8)
        val newChat = ChatEntity(
            id = chatId,
            title = name,
            phone = phone,
            avatarRes = if (isGroup) R.drawable.img_app_icon else null,
            isGroup = isGroup,
            groupMembersCount = membersCount,
            isPinned = false,
            unreadCount = 0,
            lastMessage = if (isGroup) "تم إنشاء المجموعة بنجاح" else "تم بدء محادثة جديدة عبر واتساب الاسطورة محمد",
            lastTimestamp = System.currentTimeMillis(),
            lastMessageStatus = "READ",
            isOnline = true,
            customBio = "مستخدم واتساب الاسطورة محمد 👑"
        )
        chatDao.insertChat(newChat)
        return chatId
    }

    suspend fun updateConfig(config: LegendConfigEntity) = configDao.saveConfig(config)
}
