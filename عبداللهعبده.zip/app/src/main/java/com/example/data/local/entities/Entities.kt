package com.example.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chats")
data class ChatEntity(
    @PrimaryKey val id: String,
    val title: String,
    val phone: String = "",
    val avatarRes: Int? = null,
    val isGroup: Boolean = false,
    val groupMembersCount: Int = 0,
    val isPinned: Boolean = false,
    val isArchived: Boolean = false,
    val isMuted: Boolean = false,
    val unreadCount: Int = 0,
    val lastMessage: String = "",
    val lastTimestamp: Long = System.currentTimeMillis(),
    val lastMessageStatus: String = "READ",
    val isOnline: Boolean = false,
    val customBio: String = "",
    val isVipLegend: Boolean = false,
    val isTyping: Boolean = false
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey val id: String,
    val chatId: String,
    val senderId: String,
    val senderName: String,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isFromMe: Boolean = false,
    val status: String = "SENT",
    val messageType: String = "TEXT",
    val mediaUri: String? = null,
    val mediaRes: Int? = null,
    val mediaDuration: Int = 0,
    val fileName: String? = null,
    val fileSize: String? = null,
    val isStarred: Boolean = false,
    val reaction: String? = null,
    val replyToMessageId: String? = null,
    val replyToText: String? = null
)

@Entity(tableName = "calls")
data class CallEntity(
    @PrimaryKey val id: String,
    val contactId: String,
    val contactName: String,
    val contactAvatarRes: Int? = null,
    val callType: String = "VOICE", // VOICE, VIDEO
    val direction: String = "INCOMING", // INCOMING, OUTGOING, MISSED
    val timestamp: Long = System.currentTimeMillis(),
    val durationSeconds: Int = 0
)

@Entity(tableName = "statuses")
data class StatusEntity(
    @PrimaryKey val id: String,
    val authorName: String,
    val authorAvatarRes: Int? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val text: String = "",
    val bgColorHex: String = "#0A192F",
    val mediaRes: Int? = null,
    val isViewed: Boolean = false,
    val isMine: Boolean = false
)

@Entity(tableName = "legend_config")
data class LegendConfigEntity(
    @PrimaryKey val id: Int = 1,
    val userName: String = "الاسطورة محمد",
    val userPhone: String = "+966 50 123 4567",
    val userBio: String = "👑 مرحباً بي في واتساب الاسطورة محمد | المراسلة الملكية",
    val userAvatarRes: Int? = null,
    val isLoggedIn: Boolean = true,
    val hideOnlineStatus: Boolean = false,
    val hideSecondTick: Boolean = false,
    val hideBlueTicks: Boolean = false,
    val antiDeleteMessages: Boolean = true,
    val autoReplyEnabled: Boolean = false,
    val autoReplyText: String = "مرحباً، أنا غير متاح حالياً عبر واتساب الاسطورة محمد. سأرد عليك لاحقاً!",
    val securityLockEnabled: Boolean = false,
    val securityPin: String = "1234",
    val themeStyle: String = "ROYAL_GOLD"
)
